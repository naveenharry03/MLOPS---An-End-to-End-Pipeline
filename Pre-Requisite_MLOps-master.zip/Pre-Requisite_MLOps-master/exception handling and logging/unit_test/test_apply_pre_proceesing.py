# 1. Write a test case to check
# if the FEATURES_TO_ENCODE constant
# is not coming as null and
# all the list elements are
# string in data type


# 2. Write a test case to ensure that the shape of the 
# dataframes are consistent after one hot encoding
# and data normlization