# 1. Write test case to validate if length of 
# ONE_HOT_ENCODED_FEATURES list is matching the 
# number of columns of the 
# input dataframe to encode_features()


# 2. Write a test case to ensure all
# categorical values are converted to
# vector encodings